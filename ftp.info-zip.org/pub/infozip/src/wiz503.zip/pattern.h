/*

      Copyright (c) 1990-1999 Info-ZIP.  All rights reserved.

      See the accompanying file LICENSE (the contents of which are also
      included in unzip.h, zip.h and wiz.h) for terms of use.  If, for
      some reason, all of these files are missing, the Info-ZIP license
      also may be found at:  ftp://ftp.cdrom.com/pub/infozip/license.html

*/
#define IDM_PATTERN_PATTERN  101

#define IDM_PATTERN_TEXT            100
#define IDM_PATTERN_SELECT          102
#define IDM_PATTERN_CANCEL          103
#define IDM_PATTERN_HELP            104
#define IDM_PATTERN_DESELECT        105
