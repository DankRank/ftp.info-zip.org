VC8 LIB and DLL Readme

This directory has VC8 projects for compiling the Zip LIB and DLL libraries.
These projects use the Zip source tree as well as files in the windll
directory.  These projects create directories for the output files.

Ed Gordon
27 February 2009
