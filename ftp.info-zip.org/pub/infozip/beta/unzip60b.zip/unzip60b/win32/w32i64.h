/* w32i64.h - large file includes
*/

/*
  Copyright (c) 1990-2004 Info-ZIP.  All rights reserved.

  See the accompanying file LICENSE, version 2000-Apr-09 or later
  (the contents of which are also included in unzip.h) for terms of use.
  If, for some reason, all these files are missing, the Info-ZIP license
  also may be found at:  ftp://ftp.info-zip.org/pub/infozip/license.html
*/
/*---------------------------------------------------------------------------
    Win32 specific configuration section:
  ---------------------------------------------------------------------------*/

#ifndef __w32i64_h
#define __w32i64_h

/* Large File Support
 * (pasted here from Zip 3b, osdep.h - Myles Bennett 7-jun-2004)
 * (updated from Zip 3.0d - Ed Gordon 6-oct-2004)
 *
 *  If this is set it is assumed that the port
 *  supports 64-bit file calls.  The types are
 *  defined here.  Any local implementations are
 *  in Win32.c and the protypes for the calls are
 *  in unzip.h.  Note that a port must support
 *  these calls fully or should not set 
 *  LARGE_FILE_SUPPORT.
 */

/* If port has LARGE_FILE_SUPPORT then define here
   to make automatic unless overridden */

/* MS C and VC */
#if defined(_MSC_VER) || defined(__MINGW32__) || defined(__CYGWIN__)
# ifndef LARGE_FILE_SUPPORT
#   ifndef NO_LARGE_FILE_SUPPORT
#     define LARGE_FILE_SUPPORT
#   endif
# endif
#endif


#ifdef LARGE_FILE_SUPPORT
  /* 64-bit Large File Support */

# if (defined(__GNUC__) || defined(ULONG_LONG_MAX))
    /* GNU C */

    /* base type for file offsets and file sizes */
    typedef long long    zoff_t;

    /* 64-bit stat struct */
    typedef struct stat z_stat;

    /* printf format size prefix for zoff_t values */
#   define FZOFFT_FMT "ll"
#   define FZOFFT_HEX_WID_VALUE "16"

#   define SHORTHDRSTATS "%9llu  %02u%c%02u%c%02u %02u:%02u  %c"
#   define SHORTFILETRAILER " --------                   -------\n%9llu                   %9lu file%s\n"

# elif (defined(__WATCOMC__) && (__WATCOMC__ >= 1100))
    /* WATCOM C */

    /* base type for file offsets and file sizes */
    typedef __int64      zoff_t;

    /* 64-bit stat struct */
    typedef struct stat z_stat;

    /* printf format size prefix for zoff_t values */
#   define FZOFFT_FMT "ll"
#   define FZOFFT_HEX_WID_VALUE "16"

#   define SHORTHDRSTATS "%9llu  %02u%c%02u%c%02u %02u:%02u  %c"
#   define SHORTFILETRAILER " --------                   -------\n%9llu                   %9lu file%s\n"

# elif (defined(_MSC_VER) && (_MSC_VER >= 1100))
    /* MS C and VC */

    /* base type for file offsets and file sizes */
    typedef __int64      zoff_t;

    /* 64-bit stat struct */
    typedef struct _stati64 z_stat;

    /* printf format size prefix for zoff_t values */
#   define FZOFFT_FMT "I64"
#   define FZOFFT_HEX_WID_VALUE "16"

#   define SHORTHDRSTATS "%9I64u  %02u%c%02u%c%02u %02u:%02u  %c"
#   define SHORTFILETRAILER " --------                   -------\n%9I64u                   %9lu file%s\n"

# elif (defined(__IBMC__) && (__IBMC__ >= 350))
    /* IBM C */

    /* base type for file offsets and file sizes */
    typedef __int64              zoff_t;

    /* 64-bit stat struct */

    /* printf format size prefix for zoff_t values */
#   define FZOFFT_FMT "I64"
#   define FZOFFT_HEX_WID_VALUE "16"

#   define SHORTHDRSTATS "%9I64u  %02u%c%02u%c%02u %02u:%02u  %c"
#   define SHORTFILETRAILER " --------                   -------\n%9I64u                   %9lu file%s\n"

# else
#   undef LARGE_FILE_SUPPORT
# endif

#endif /* LARGE_FILE_SUPPORT */


/* Automatically set ZIP64_SUPPORT if supported */

/* MS C and VC */
#ifdef _MSC_VER
# ifdef LARGE_FILE_SUPPORT
#   ifndef NO_ZIP64_SUPPORT
#     ifndef ZIP64_SUPPORT
#       define ZIP64_SUPPORT
#     endif
#   endif
# endif
#endif


#ifndef LARGE_FILE_SUPPORT
  /* No Large File Support */

  /* base type for file offsets and file sizes */
  typedef long zoff_t;

  /* stat struct */
  typedef struct stat z_stat;

#  define FZOFFT_FMT "l"
#  define FZOFFT_HEX_WID_VALUE "8"


#  define SHORTHDRSTATS "%9lu  %02u%c%02u%c%02u %02u:%02u  %c"
#  define SHORTFILETRAILER " --------                   -------\n%9lu                   %9lu file%s\n"

#endif /* LARGE_FILE_SUPPORT */


#endif /* !__w32i64_h */
