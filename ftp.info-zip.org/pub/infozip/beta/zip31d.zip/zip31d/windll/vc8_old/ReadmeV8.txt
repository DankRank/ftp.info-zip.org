VC8 LIB and DLL Readme

The VS 2008 projects have not been updated for Zip 3.1.

This directory has VC8 projects for compiling the Zip LIB and DLL libraries.
These projects use the Zip source tree as well as files in the windll
directory.  These projects create directories for the output files.

31 July 2014
