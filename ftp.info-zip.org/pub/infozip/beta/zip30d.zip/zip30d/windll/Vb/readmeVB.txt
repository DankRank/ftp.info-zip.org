On Windows open this file in WordPad.

Contents of the "windll/vb" sub-archive

This directory contains a Visual Basic project example for using the
zip32.dll library.  See the comments in the form and project files
for details.

Note that the files are saved in unix format with carriage returns
stripped.  These must be restored before the project can be successfully
used.  This can be done by using the -a option to unzip.  Another way to
do this is to open each file in WordPad, select and cut a line, paste
the line back, and save the file.  This will force WordPad to format
the entire file.

Ed Gordon
10/20/2003
