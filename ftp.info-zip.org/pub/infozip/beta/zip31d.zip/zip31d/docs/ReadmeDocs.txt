docs/ReadmeDocs.txt

This directory contains plain text versions of the manual pages
in /man/man1.  These are the manuals for zip, zipcloak, zipnote
and zipsplit.

These were generated using the "docs" target of unix/Makefile.
