VC6BZ2 LIB and DLL Readme

This directory has VC6 projects for compiling the Zip LIB and DLL libraries.
These projects use the Zip source tree as well as files in the windll
directory.  These projects create directories for the output files.

This directory looks for and includes bzip2 in the LIB and DLL.  You must
have dropped bzip2 in the bzip2 directory.  See bzip2/install.txt for how.

Ed Gordon
10 May 2010
