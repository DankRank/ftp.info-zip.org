/*

      Copyright (c) 1990-1999 Info-ZIP.  All rights reserved.

      See the accompanying file LICENSE (the contents of which are also
      included in unzip.h, zip.h and wiz.h) for terms of use.  If, for
      some reason, all of these files are missing, the Info-ZIP license
      also may be found at:  ftp://ftp.cdrom.com/pub/infozip/license.html

*/
#define IDM_SOUND_NONE        101
#define IDM_SOUND_BEEP        102
#define IDM_SOUND_WAVE_DURING 103
#define IDM_SOUND_WAVE_AFTER  104
#define IDM_SOUND_BROWSE      105
#define IDM_SOUND_EDIT        106
#define IDM_SOUND_FILE_TEXT   107
#define IDM_SOUND_PLAY        108

