VC6 LIB and DLL Examples Readme

This directory has VC6 example projects for showing how to use the Zip LIB
and DLL libraries.

c_dll_ex contains the DLL example.  Once the example is compiled, the DLL
must be in the user PATH to run the example.

c_lib_ex contains the LIB example.  To compile the example, you must place
the compiled library in that directory.

As of Zip 3.1c beta, neither of these are completely up to date with the
latest DLL structures.  These examples should be updated by the next
beta.

Ed Gordon
19 June 2010
