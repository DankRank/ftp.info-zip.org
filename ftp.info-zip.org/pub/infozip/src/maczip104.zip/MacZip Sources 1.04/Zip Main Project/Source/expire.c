/*  Test-Programm, das nach einiger Zeit ablaeuft (expired)  */



#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define EXPIRE_TIME	  2 * 28 * 24 * 3600L	/*  Beta:    8 weeks   */

static time_t get_cctime (void);
static void when_expired (const char* prog_version, Boolean print);
static int expired (const char* prog_version, Boolean print);
int test_expired(int argc, char *argv[], Boolean print);



/*
 *  NAME
 *	expired, when_expired
 *
 *  DESCRIPTION
 *	To avoid unnessary support for test versions which maybe left this
 *	version expires after a certain time (see the EXPIRE_TIME macro
 *	above).
 *
 *	If less than half of the EXPIRE_TIME is left the user is warned that
 *	the test version will expire.
 *
 *	when_expired() prints out the expiration time.
 *
 *	get_cctime returns the compile time as 'time_t' value.
 */


static time_t get_cctime (void)
{
    struct tm 	ct = {0, 0, 0, 0, 0, 0, 0, 0, -1};	/* compile time */
    time_t	cctime;					/* compile */
    char	mon[4];					/* month as Mmm */
    int		yyyy;					/* year as yyyy */
    
    /*  get compile date  */
    sscanf (__DATE__, "%s%d%d", mon, &(ct.tm_mday), &yyyy);
    if (strcmp (mon, "Jan") == 0) {
	ct.tm_mon = 0;
    } else if (strcmp (mon, "Feb") == 0) {
	ct.tm_mon = 1;
    } else if (strcmp (mon, "Mar") == 0) {
	ct.tm_mon = 2;
    } else if (strcmp (mon, "Apr") == 0) {
	ct.tm_mon = 3;
    } else if (strcmp (mon, "May") == 0) {
	ct.tm_mon = 4;
    } else if (strcmp (mon, "Jun") == 0) {
	ct.tm_mon = 5;
    } else if (strcmp (mon, "Jul") == 0) {
	ct.tm_mon = 6;
    } else if (strcmp (mon, "Aug") == 0) {
	ct.tm_mon = 7;
    } else if (strcmp (mon, "Sep") == 0) {
	ct.tm_mon = 8;
    } else if (strcmp (mon, "Oct") == 0) {
	ct.tm_mon = 9;
    } else if (strcmp (mon, "Nov") == 0) {
	ct.tm_mon = 10;
    } else if (strcmp (mon, "Dec") == 0) {
	ct.tm_mon = 11;
    } else {
	fprintf (stderr, "WARNING: wrong time stamp '" __DATE__ "' in code!\n" );
    }
    ct.tm_year = yyyy - 1900;
    sscanf (__TIME__, "%d:%d:%d", &(ct.tm_hour), &(ct.tm_min), &(ct.tm_sec));
       
    /*  return compile time as 'time_t'  */
    cctime = mktime (&ct);
    return (cctime);
}


static void when_expired (const char* prog_version, Boolean print )
{
    time_t extime;
    
    extime = get_cctime() + EXPIRE_TIME;
    if (print) fprintf (
	stdout, 
	"\n\tNote:\tthis test version\n"
	"\t\t\"%s\"\n"
	"\t\twill expire at %s\n",
	prog_version,
	ctime (&extime)
    );
}


static int expired (const char* prog_version, Boolean print)
{
    time_t	cctime, runtime;			/* compile/runtime */
    
    /*  get difference time  */
    cctime = get_cctime();
    runtime = time (NULL);

    if (difftime (runtime, cctime) > EXPIRE_TIME) {
	if (print) fprintf (
	    stdout, 
	    "\n\tSorry, this test version\n\n"
	    "\t\t\"%s\"\n\n"
	    "\thas expired\n",
	    prog_version
	);
	if (print) fprintf (stdout,"\tplease use a newer one or an official version.\n\n");
	return EXIT_FAILURE;
    }

    /*  should I warn the user?  */
    if (difftime (runtime, cctime) > EXPIRE_TIME / 2) {
	when_expired (prog_version, print);
    }
    
return EXIT_SUCCESS;
}




/*
 *  NAME
 *	test_expired
 *
 *  DESCRIPTION
 *	First it scans the different options (for the meaning of the option
 *	see 'help_string').
 */


int test_expired(int argc, char *argv[], Boolean print)
{
    char version[101];
    int	result;
    
    argc = argc;

    sprintf (version, "%s - Version " __DATE__ "  ", argv[0] );
    
    /*  test version expired?  */
    result = expired (version, print);
    when_expired (version, print);

    return result;
}

