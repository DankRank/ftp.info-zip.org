Betas are works in progress.  When a beta has a seemingly stable set
of features, we may post a public beta so outside developers can see
where the code is going and make contributions or comment.  This package
is a public beta.

A Release Candidate is a beta that we believe has the full feature
set that will be released.  It's still being tested, and things can
still change, but we thought it close when we posted it.  This package
is also a release candidate.  (Yes, it's been a while in coming and
we're shocked too.)

We take suggestions and bug fixes at any time and will still make
bug fixes to a release candidate until release, so send those suggestions,
discovered bugs, and patches in.

We make no guarantees as to the state of these betas so use at your own
risk.  The Info-ZIP license applies to all postings, including betas.

Enjoy!

Ed Gordon
27 December 2007
