/* 2011-04-21 SMS.
 * VMS-specific <memory.h> for AES encryption code.
 * This should be equivalent to the DEC C <memory.h> which is supplied
 * on newer systems, but which may be missing on older systems.
 */
#ifndef _MEMORY_H
#define _MEMORY_H 1

#include <string.h>

#endif  /* ndef _MEMORY_H */
