VC8 LIB and DLL Examples Readme

This directory has VC8 example projects for showing how to use the Zip LIB
and DLL libraries.

Special thanks to 107E5eng from the Info-ZIP forum for providing the
initial VC8 LIB project that the VC8 LIB example is based on.

Ed Gordon
27 February 2009
