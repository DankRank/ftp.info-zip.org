ReadVC6.txt - Visual Studio 6 LIB and DLL 

This directory (vc6) has VC6 projects for compiling the Zip LIB and DLL
libraries.  These projects use the Zip source tree as well as files in
the windll directory.  These projects create directories for the output
files.

Inclusion of additional compression methods (bzip2, LZMA, and PPMd) and
AES encryption are now controlled by control.h.  See INSTALL for how to
enable AES encryption.

13 September 2015

