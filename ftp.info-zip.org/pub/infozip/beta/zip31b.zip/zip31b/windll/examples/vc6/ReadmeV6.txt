VC6 LIB and DLL Examples Readme

This directory has VC6 example projects for showing how to use the Zip LIB
and DLL libraries.

Ed Gordon
27 February 2009
