On Windows open this file in WordPad.

Contents of the "windll/csharp" sub-archive

This directory contains Visual C Sharp (C#) sample project for
using the unzip32.dll library.  This project was generously donated
by Adrian Maull.  The Zip source archive contains a corresponding
project for using the zip32.dll library.

The project is based on .NET Framework 1.1.  It was contributed
to the Info-Zip project April 2005.  If you have questions or comments,
contact us at www.Info-ZIP.org or for specific questions about these
projects contact Adrian Maull directly at adrian.maull@sprintpcs.com.

See UnZip.cs for more detailed information about the project.  Currently
the sample project has some bugs as noted in the above file.
The original code has been adapted to the modified WinDLL interface of
UnZip 6, using Visual C# 2005 (.Net Framework 2.0) and a unzip32.dll compiled
by Visual C++ 6.0.  The provided project file is still in the format for
Visual Studio 7.1 (VS .Net 2003, .Net 1.1).  But the code of the project
can be used with newer Visual Studio versions (2005 = 8.0 or 2008 = 9.0);
only the project file gets (irreveribly) converted to the newer Visual
Studio format when first opened.
However, this project is not tested throughoutly by us at this time.

These sample projects are distributed as part of the Info-ZIP distribution
under the Info-ZIP license.

Note that the files may be saved in "UNIX LF" format with carriage returns
stripped.  These may need to be restored before the project can be successfully
used.

Ed Gordon, Christian Spieler
2009/01/11
