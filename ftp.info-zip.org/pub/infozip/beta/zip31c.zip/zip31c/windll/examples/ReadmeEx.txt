WinDLL Examples Readme

This directory has projects for example programs showing how to use
the Win32 versions of the Zip LIB and DLL.  The C examples generally
use example.h and example.c in this directory, while other projects
such as for Visual Basic and C# have their own code.

These are more or less minimum examples showing the basics.  They
probably need some work before use in any real situation.

As of this Zip 3.1c beta, only the VBz64 example in the
windll/examples/VBz64
directory incorporates the latest API structures and callbacks.
The other examples should be updated before Zip 3.1 is released.

Ed Gordon
19 June 2010
